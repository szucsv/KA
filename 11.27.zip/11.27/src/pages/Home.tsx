import { useEffect, useState } from "react";
import type { Pizza } from "../types/Pizza";
import apiClient from "../apiClient/apiClient";
import {Button,Card, Container, Nav, Navbar, Row} from "react-bootstrap";

const Home = () => {
  const [pizzas, setPizzas] = useState<Array<Pizza>>([]);

  useEffect(() => {
    apiClient
      .get("/pizzak")
      .then((res) => setPizzas(res.data))
      .catch((err) => console.log(err.message));
  }, []);

  const deleteButton = (p: Pizza) => {
    apiClient
      .delete(`/pizzak/${p.id}`)
      .then(() => {
        setPizzas((prev) => prev.filter((e) => e.id !== p.id));
      })
      .catch((err) => alert(err.message));
  };


    const generateCard = (p: Pizza) => {
    return (<>
         <Card style={{ width: "18rem" }}>
          <Card.Body>
    
            <Card.Title>{p.nev}</Card.Title>
            <Card.Text> {p.leiras}</Card.Text>
            <Card.Img src={p.imageUrl}/>
            <Card.Footer>{p.ar}</Card.Footer>
          </Card.Body>
          <Card.Footer>
            <Button onClick={() => deleteButton(p)}>Delete</Button>
          </Card.Footer>
        </Card>
    </>
  )
    }
    
  return (
    <>
      <Navbar expand="lg" className="bg-body-tertiary">
        <Container>
          <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/add">Add a Pizza</Nav.Link>
                <Nav.Link href="/add">OnePizza</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Row>{pizzas.map((e) => generateCard(e))}</Row>
    </>
  );
}
export default Home;