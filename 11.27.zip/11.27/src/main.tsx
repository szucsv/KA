import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import "bootstrap/dist/css/bootstrap.min.css";


createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>} />
        {/* <Route path="/m/:id" element={<OnePizza />} />
        <Route path="/add" element={<AddPizza />} /> */}
        <Route path="*" element={<h1>ERROR 404 - Page not found!</h1>} />
      </Routes>
    </BrowserRouter>
      </StrictMode>

)
